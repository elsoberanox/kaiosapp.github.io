
// Opens the site in a remote browser frame, and close ourselves.
window.setTimeout(() => {
    window.open("https://invidious.snopyta.org/feed/popular", '_blank');
    window.close();
}, 1000);
